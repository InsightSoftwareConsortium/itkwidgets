=======
Credits
=======

Development Lead
----------------

* John Kirkham `@jakirkham <https://github.com/jakirkham>`_

Contributors
------------

See the full list of contributors `here <https://github.com/dask/dask-image/graphs/contributors>`_
